import React from 'react'

export default function Govde() {
  return (
    <div>
      <header className="header">biyografi</header>
      <div className="photo">
        <img className="mainPicture" src="./src/images/Fotom.jpg" alt="Avatar"></img>
      </div>
    </div>
  )
}
