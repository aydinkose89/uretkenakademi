import React from 'react'

const Text=()=> {
  return (
    <div className='text'>
       <center>
        <h3>Aydın Köse</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum blanditiis quae dolore itaque aliquid quis, laborum, esse eum assumenda beatae laudantium consequatur labore minima illum. Dolores deleniti consequatur tenetur necessitatibus illum! Amet ipsum ex facere ea animi! Ipsam exercitationem blanditiis, dolor vero corrupti repellat sapiente eligendi atque deserunt, eos suscipit, praesentium ex temporibus. Fuga commodi, magni sunt qui architecto dolorum fugiat aspernatur voluptatem delectus est dignissimos dolores veniam unde. Dolores aut aliquid rerum repudiandae natus nemo consequatur unde dolorum quo, consequuntur nulla deserunt blanditiis? Delectus, fugit blanditiis, commodi culpa necessitatibus veniam est debitis, quibusdam odit minus libero architecto sit aut.</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, facilis libero! Magnam fugit, cupiditate consequuntur neque deleniti, nihil vitae labore sit, velit nesciunt reiciendis corporis eligendi suscipit iusto possimus explicabo! Ipsa expedita corporis incidunt distinctio aspernatur. Quidem libero sunt odio eum quia exercitationem veniam, accusantium accusamus, nostrum, fuga maxime rerum!</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod beatae adipisci culpa! Odit, reprehenderit provident fuga ea neque molestiae excepturi quasi, maiores commodi adipisci ab.</p>
       </center>

    </div>
  )
}


export default Text;