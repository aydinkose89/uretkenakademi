
import React from 'react'

const Navbar=()=> {
  return (
    <div>
        <ul className="navbar">
        <li className="navbarItem"><a className="oge" href="">Ana Sayfa</a></li>
        <li className="navbarItem"><a className="oge" href="">Öğrenim Geçmişi</a></li>
        <li className="navbarItem"><a className="oge" href="">İş Hayatı</a></li>
        <li className="navbarItem"><a className="oge" href="">İletişim</a></li>
        </ul>

    </div>
  )
}


export default Navbar;