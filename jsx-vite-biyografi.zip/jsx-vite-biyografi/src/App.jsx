import './App.css';
import Govde from './components/Govde';
import Navbar from "./components/Navbar";
import Text from "./components/Text";
import Footer from "./components/Footer";


function App() {
  

  return (
    <>
     <Navbar/>
     <Govde/>
     <Text/>
     <Footer/>
    </>
  )
}

export default App
